## Summary

<!-- One sentence describing what this PR does -->

## Type of Change

- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature / module (non-breaking change that adds functionality)
- [ ] Breaking change (existing behaviour changes)
- [ ] Documentation update
- [ ] Refactor / code cleanup
- [ ] CI / tooling update

## What Changed

<!-- Bullet points: what was added, removed, or modified -->

-
-

## Related Issues

<!-- Link issues: "Fixes #123" or "Relates to #456" -->

Fixes #

## Testing

<!-- Describe how you tested this change -->

- [ ] Added / updated unit tests in `tests/`
- [ ] Ran `pytest tests/ -v` locally — all tests pass
- [ ] Ran `flake8` and `black --check` locally — no errors
- [ ] Tested against a real target (authorized research only)

## Module Checklist (for new modules)

If this PR adds a new module, confirm:

- [ ] Module is in `modules/` and follows the existing class pattern
- [ ] Module is imported and wired in `main.py` (interactive menu + CLI flag)
- [ ] New API keys (if any) added to `config.py` and `.env.example`
- [ ] Dependencies added to `requirements.txt`
- [ ] README.md module table updated
- [ ] Basic test class added to `tests/test_modules.py`
- [ ] CHANGELOG.md updated under `[Unreleased]`

## Screenshots / Output

<!-- Paste anonymized example output if helpful -->

```
```

## Checklist

- [ ] My code follows the existing code style
- [ ] I have not hardcoded any real API keys or credentials
- [ ] Sensitive output (real IPs, emails, etc.) is removed from examples
- [ ] I confirm I am only targeting systems I am authorized to investigate
